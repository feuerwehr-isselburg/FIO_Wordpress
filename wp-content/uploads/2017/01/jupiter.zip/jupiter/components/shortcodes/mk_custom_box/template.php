<div class="mk-custom-box">
	<div class="box-holder">
		<div class="clearfix"></div>
	</div>
</div> 