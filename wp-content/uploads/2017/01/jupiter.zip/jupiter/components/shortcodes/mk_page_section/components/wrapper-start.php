
<div class="clearboth"></div>
	</div> <?php // closing tag : theme-content ?>
		</div> <?php // closing tag : theme-page-wrapper ?>
			</div> <?php // closing tag : mk-main-wrapper-holder ?>


				<?php 
				/* Fixes page section for blog single page */
				if(is_singular('post')) { ?>
				    </div>
				<?php
				}